package com.example.imageview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {
    boolean img =true;
    public void change(View view) {
        ImageView iv = findViewById(R.id.imageView2);
        if (img)
        {
            iv.setImageResource(R.drawable.goat);
            img = false;
        }else{
            iv.setImageResource(R.drawable.img);
            img = true;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}